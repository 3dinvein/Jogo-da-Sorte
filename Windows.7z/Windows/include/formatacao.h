#ifndef FORMATACAO_H
#define FORMATACAO_H


class formatacao
{
    public:
        formatacao();
        virtual ~formatacao();
    protected:
    private:
};

#endif // FORMATACAO_H
