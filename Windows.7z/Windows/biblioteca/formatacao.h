#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

void aplicaFundo(){
system("1F");
}
