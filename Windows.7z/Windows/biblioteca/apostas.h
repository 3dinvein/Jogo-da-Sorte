#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <strings.h>
#include <time.h>

void menuAposta()
{
    int menu00;

    printf("SELECIONE UM JOGO E APOSTE\n\n");
    printf("1 - TRILEGAL\n\n");
    printf("2 - QUINA\n\n");
    printf("3 - LOTO FACIL\n\n");
    printf("4 - MEGA SENA\n\n");
    printf("5 - LOTOGOL\n\n");
    printf("6 - LOTOMANIA\n\n");
    printf("7 - TIMEMANIA\n\n");
    printf("8 - DUPLA SENA\n\n");
    printf("9 - INSTANTANEA\n\n");
    printf("10 - ( ESC ) PARA SAIR\n\n");
    scanf("%d",&menu00);



}
