#include "formatacao.h"

formatacao::formatacao()
{
    //ctor
}

formatacao::~formatacao()
{
    //dtor
}
